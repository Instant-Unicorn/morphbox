<script lang="ts">
  import { onMount } from 'svelte';
  import { browser } from '$app/environment';
  import { panels, panelStore, activePanel, type Panel } from '$lib/stores/panels';
  import Terminal from '$lib/Terminal.svelte';
  import FileExplorer from '$lib/panels/FileExplorer/FileExplorer.svelte';
  import CodeEditor from '$lib/panels/CodeEditor/CodeEditor.svelte';
  import Settings from '$lib/panels/Settings/Settings.svelte';
  import PromptQueue from '$lib/panels/PromptQueue/PromptQueue.svelte';
  import GitPanel from '$lib/panels/GitPanel/GitPanel.svelte';
  import CustomPanelRenderer from '$lib/components/CustomPanelRenderer.svelte';
  import RowPanel from '$lib/components/RowPanel.svelte';
  import PanelManager from '$lib/components/PanelManager.svelte';
  import SectionTabs from '$lib/components/SectionTabs.svelte';
  import { settings, applyTheme } from '$lib/panels/Settings/settings-store';
  import { fade } from 'svelte/transition';
  import { panelRegistry } from '$lib/panels/registry';
  import { handleFileOpen } from '$lib/utils/fileHandler';
  
  // Static component mapping for built-in panels
  const builtinComponents = {
    terminal: Terminal,
    claude: Terminal, // Legacy - maps to Terminal with autoLaunchClaude
    sandboxTerminal: Terminal,
    adminTerminal: Terminal,
    fileExplorer: FileExplorer,
    'file-explorer': FileExplorer,
    codeEditor: CodeEditor,
    'code-editor': CodeEditor,
    settings: Settings,
    promptQueue: PromptQueue,
    'prompt-queue': PromptQueue,
    gitPanel: GitPanel,
    'git-panel': GitPanel
  };
  
  // Store for dynamically loaded components
  let loadedComponents: Record<string, any> = {};
  
  // Get component for a panel type
  async function getComponentForPanel(type: string) {
    // Check built-in components first
    if (builtinComponents[type]) {
      return builtinComponents[type];
    }
    
    // Check if already loaded
    if (loadedComponents[type]) {
      return loadedComponents[type];
    }
    
    // Try to load from registry
    const panelDef = panelRegistry.get(type);
    if (panelDef) {
      // If it's a custom panel, use the CustomPanelRenderer
      if (panelDef.isCustom) {
        loadedComponents[type] = CustomPanelRenderer;
        return CustomPanelRenderer;
      }
      
      try {
        const component = await panelRegistry.loadComponent(type);
        if (component) {
          loadedComponents[type] = component;
          return component;
        }
      } catch (error) {
        console.error(`Failed to load panel component: ${type}`, error);
      }
    }
    
    return null;
  }
  
  let showLoadingOverlay = true;
  // Port is always webPort + 1 (8008->8009, 8010->8011, etc.)
  let websocketUrl = browser ? `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}:${parseInt(window.location.port) + 1}` : '';
  let layoutContainer: HTMLElement;
  
  // Row layout state
  interface Row {
    id: string;
    panels: Panel[];
    height: number; // Height in pixels
  }
  
  let rows: Row[] = [];
  let draggedPanelId: string | null = null;
  let dropTargetInfo: { rowId: string; panelId?: string; position: 'before' | 'after' | 'split' } | null = null;
  
  // Responsive state
  let viewportWidth = browser ? window.innerWidth : 1200;
  let viewportHeight = browser ? window.innerHeight : 800;
  let isCompactMode = false;
  let stackedLayout = false;
  
  // Responsive breakpoints
  const BREAKPOINTS = {
    mobile: 768,
    tablet: 1024,
    desktop: 1280
  };
  
  // Update responsive state based on viewport
  function updateResponsiveState() {
    if (!browser) return;
    
    viewportWidth = window.innerWidth;
    viewportHeight = window.innerHeight;
    
    // Determine if we should stack panels
    const shouldStack = viewportWidth < BREAKPOINTS.mobile || 
                       (rows.some(row => row.panels.length > 2) && viewportWidth < BREAKPOINTS.tablet);
    
    if (shouldStack !== stackedLayout) {
      stackedLayout = shouldStack;
      reorganizeLayoutForViewport();
    }
    
    isCompactMode = viewportWidth < BREAKPOINTS.tablet;
  }
  
  // Reorganize layout when viewport changes significantly
  function reorganizeLayoutForViewport() {
    if (stackedLayout) {
      // Convert multi-panel rows to single-panel rows
      const allPanels = rows.flatMap(row => row.panels);
      rows = allPanels.map((panel, index) => ({
        id: `row-${index}`,
        panels: [{ ...panel, widthPercent: 100 }],
        height: Math.max(200, viewportHeight / Math.max(3, allPanels.length))
      }));
    } else {
      // Restore original layout from server
      loadLayoutFromServer();
    }
  }
  
  // Debounce function for resize events
  function debounce(func: Function, wait: number) {
    let timeout: NodeJS.Timeout;
    return function executedFunction(...args: any[]) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
  
  // Initialize on mount
  onMount(async () => {
    console.log('🚀 RowLayout: Component mounted');
    
    // Ensure loading overlay is removed even if there's an error
    const removeLoadingOverlay = () => {
      showLoadingOverlay = false;
      console.log('🎭 Loading overlay removed');
    };
    
    // Set timeout to remove overlay
    const timeoutId = setTimeout(removeLoadingOverlay, 750);
    
    // Failsafe: Remove overlay after 3 seconds no matter what
    const failsafeTimeoutId = setTimeout(() => {
      if (showLoadingOverlay) {
        console.warn('⚠️ Failsafe: Forcing loading overlay removal after 3 seconds');
        removeLoadingOverlay();
      }
    }, 3000);
    
    let unsubscribe: (() => void) | undefined;
    
    try {
      settings.load();
      unsubscribe = settings.subscribe($settings => {
        applyTheme($settings.theme, $settings.customTheme);
        
        // Apply panel spacing
        if ($settings.panels?.panelSpacing !== undefined) {
          document.documentElement.style.setProperty('--panel-spacing', `${$settings.panels.panelSpacing}px`);
        }
      });
    } catch (error) {
      console.error('❌ Error during initialization:', error);
      // Make sure overlay is removed even on error
      clearTimeout(timeoutId);
      removeLoadingOverlay();
    }
    
    // Set up responsive handling
    updateResponsiveState();
    
    // Debounced resize handler
    const debouncedResize = debounce(updateResponsiveState, 150);
    
    // Add resize listener
    window.addEventListener('resize', debouncedResize);
    
    // Listen for file open events to create code editor in new row
    const handleCreatePanelForFile = (event: CustomEvent) => {
      const { type, config } = event.detail;
      console.log('[RowLayout] Handling create-panel-for-file event:', { type, config });
      addNewPanel(type, config);
    };
    window.addEventListener('create-panel-for-file', handleCreatePanelForFile);
    
    // Add ResizeObserver for container-based responsiveness
    let resizeObserver: ResizeObserver;
    if (layoutContainer && 'ResizeObserver' in window) {
      resizeObserver = new ResizeObserver(debounce(() => {
        updateResponsiveState();
      }, 150));
      resizeObserver.observe(layoutContainer);
    }
    
    // Load saved layout from server OR initialize if empty
    setTimeout(async () => {
      // Clear any stale sessionStorage data that might conflict
      if (browser && sessionStorage.getItem('morphbox-panel-state')) {
        const staleData = sessionStorage.getItem('morphbox-panel-state');
        console.log('⚠️ Clearing potentially stale sessionStorage data:', staleData);
        sessionStorage.removeItem('morphbox-panel-state');
      }
      
      const loaded = await loadLayoutFromServer();
      if (!loaded && $panels.length === 0) {
        initializeLayout();
      }
      // Update responsive state after layout loads
      updateResponsiveState();
      
      // Log actual rendered dimensions after DOM updates
      setTimeout(() => {
        logRenderedDimensions();
      }, 100);
    }, 50);
    
    return () => {
      clearTimeout(timeoutId);
      clearTimeout(failsafeTimeoutId);
      
      if (typeof unsubscribe === 'function') {
        unsubscribe();
      }
      window.removeEventListener('resize', debouncedResize);
      window.removeEventListener('create-panel-for-file', handleCreatePanelForFile);
      if (resizeObserver) {
        resizeObserver.disconnect();
      }
    };
  });
  
  // Initialize layout with Sandbox Terminal and Prompt Queue
  function initializeLayout() {
    panelStore.clear();

    // Get row height from settings
    const currentSettings = $settings;
    const rowHeight = currentSettings.panels?.rowHeight || 400;

    const newPanel = panelStore.addPanel('sandboxTerminal', {
      title: 'Sandbox Terminal',
      rowIndex: 0,
      widthPercent: 100,
      heightPixels: rowHeight,
      orderInRow: 0
    });
    
    // Create initial row
    rows = [{
      id: 'row-0',
      panels: [$panels[0]],
      height: rowHeight
    }];
  }
  
  // Organize panels into rows
  function organizePanelsIntoRows() {
    const rowMap = new Map<number, Panel[]>();
    
    // Get default row height from settings
    const currentSettings = $settings;
    const defaultRowHeight = currentSettings.panels?.rowHeight || 400;
    
    console.log('🔍 organizePanelsIntoRows: Starting organization');
    console.log('Total panels:', $panels.length);
    console.log('All panels details:', $panels.map(p => ({
      id: p.id,
      type: p.type,
      title: p.title,
      rowIndex: p.rowIndex,
      widthPercent: p.widthPercent,
      orderInRow: p.orderInRow
    })));
    console.log('Call stack:', new Error().stack?.split('\n').slice(2, 5).join('\n'));
    
    // Group panels by row index
    $panels.forEach(panel => {
      const rowIndex = panel.rowIndex ?? 0;
      if (!rowMap.has(rowIndex)) {
        rowMap.set(rowIndex, []);
      }
      rowMap.get(rowIndex)!.push(panel);
      
      console.log(`Panel ${panel.id}:`, {
        type: panel.type,
        title: panel.title,
        rowIndex: panel.rowIndex,
        widthPercent: panel.widthPercent,
        orderInRow: panel.orderInRow
      });
    });
    
    // Sort panels within each row by orderInRow
    rowMap.forEach(panelsInRow => {
      panelsInRow.sort((a, b) => (a.orderInRow ?? 0) - (b.orderInRow ?? 0));
    });
    
    // Convert to rows array
    rows = Array.from(rowMap.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([index, panels]) => ({
        id: `row-${index}`,
        panels,
        height: panels[0]?.heightPixels ?? defaultRowHeight
      }));
      
    console.log('📊 Organized rows:', rows.map(row => ({
      id: row.id,
      panelCount: row.panels.length,
      totalWidth: row.panels.reduce((sum, p) => sum + (p.widthPercent || 0), 0),
      height: row.height
    })));
  }
  
  // Handle panel drag start
  function handleDragStart(event: CustomEvent) {
    draggedPanelId = event.detail.panelId;
  }
  
  // Handle panel drag end
  function handleDragEnd() {
    draggedPanelId = null;
    dropTargetInfo = null;
  }
  
  // Handle panel drop
  function handlePanelDrop(event: CustomEvent) {
    const { rowId, targetPanelId, position } = event.detail;
    if (!draggedPanelId) return;
    
    const draggedPanel = $panels.find(p => p.id === draggedPanelId);
    if (!draggedPanel) return;
    
    if (position === 'split' && targetPanelId) {
      // Split the target panel
      splitPanel(targetPanelId, draggedPanelId);
    } else {
      // Move panel to new position
      movePanel(draggedPanelId, rowId, targetPanelId, position);
    }
    
    // Always clear dragged panel after drop
    draggedPanelId = null;
    dropTargetInfo = null;
    
    saveLayoutToServer();
  }
  
  // Split a panel with another panel
  function splitPanel(targetPanelId: string, draggedPanelId: string) {
    const targetPanel = $panels.find(p => p.id === targetPanelId);
    const draggedPanel = $panels.find(p => p.id === draggedPanelId);
    
    if (!targetPanel || !draggedPanel) return;
    
    const targetRow = rows.find(row => row.panels.some(p => p.id === targetPanelId));
    if (!targetRow) return;
    
    // Check if row already has 4 panels (maximum)
    if (targetRow.panels.length >= 4) {
      console.log('Row already has maximum 4 panels, cannot add more');
      // Create a new row below instead
      const newRowIndex = Math.max(...rows.map(r => parseInt(r.id.split('-')[1]))) + 1;
      panelStore.updatePanel(draggedPanelId, {
        rowIndex: newRowIndex,
        heightPixels: targetPanel.heightPixels,
        orderInRow: 0,
        widthPercent: 100
      });
    } else {
      // Move dragged panel to same row
      panelStore.updatePanel(draggedPanelId, {
        rowIndex: targetPanel.rowIndex,
        heightPixels: targetPanel.heightPixels,
        orderInRow: (targetPanel.orderInRow ?? 0) + 1
      });
      
      // Update order of other panels in the row
      targetRow.panels.forEach(panel => {
        if (panel.orderInRow !== undefined && panel.orderInRow > (targetPanel.orderInRow ?? 0)) {
          panelStore.updatePanel(panel.id, {
            orderInRow: panel.orderInRow + 1
          });
        }
      });
    }
    
    organizePanelsIntoRows();
    
    // After organizing, recalculate widths to fit all panels equally
    setTimeout(() => {
      recalculateRowWidths(true);
      saveLayoutToServer();
    }, 0);
  }
  
  // Move panel to new position
  function movePanel(panelId: string, rowId: string, targetPanelId?: string, position?: 'before' | 'after') {
    const panel = $panels.find(p => p.id === panelId);
    if (!panel) return;
    
    // Store the original row index to recalculate its widths later
    const originalRowIndex = panel.rowIndex;
    
    const rowIndex = parseInt(rowId.split('-')[1]);
    const targetRow = rows.find(r => r.id === rowId);
    
    // Check if target row already has 4 panels (excluding the dragged panel if it's from the same row)
    const panelsInTargetRow = targetRow ? targetRow.panels.filter(p => p.id !== panelId) : [];
    if (panelsInTargetRow.length >= 4) {
      console.log('Target row already has maximum 4 panels, creating new row');
      // Create a new row instead
      const newRowIndex = Math.max(...rows.map(r => parseInt(r.id.split('-')[1])), -1) + 1;
      panelStore.updatePanel(panelId, {
        rowIndex: newRowIndex,
        orderInRow: 0,
        heightPixels: targetRow?.height ?? 400,
        widthPercent: 100
      });
    } else if (targetPanelId && position && targetRow) {
      // Insert before or after specific panel
      const targetPanel = targetRow.panels.find(p => p.id === targetPanelId);
      if (!targetPanel) return;
      
      const targetOrder = targetPanel.orderInRow ?? 0;
      const newOrder = position === 'before' ? targetOrder : targetOrder + 1;
      
      // Update orders of other panels
      targetRow.panels.forEach(p => {
        if (p.id !== panelId && (p.orderInRow ?? 0) >= newOrder) {
          panelStore.updatePanel(p.id, {
            orderInRow: (p.orderInRow ?? 0) + 1
          });
        }
      });
      
      // Update dragged panel
      panelStore.updatePanel(panelId, {
        rowIndex,
        orderInRow: newOrder,
        heightPixels: targetRow.height
      });
    } else {
      // Add to empty row or end of row
      const maxOrder = targetRow ? Math.max(...targetRow.panels.map(p => p.orderInRow ?? 0), -1) : -1;
      
      panelStore.updatePanel(panelId, {
        rowIndex,
        orderInRow: maxOrder + 1,
        heightPixels: targetRow?.height ?? 400
      });
    }
    
    // Reorganize first to update row structures
    organizePanelsIntoRows();
    
    // Always recalculate widths after moving panels
    setTimeout(() => {
      recalculateRowWidths(true);
      saveLayoutToServer();
    }, 0);
  }
  
  // Recalculate panel widths within rows
  function recalculateRowWidths(forceEqualWidths = false, isInitialLoad = false) {
    console.log('🔄 recalculateRowWidths called:', { forceEqualWidths, isInitialLoad });
    
    rows.forEach(row => {
      const panelCount = row.panels.length;
      if (panelCount > 0) {
        // Always recalculate to ensure panels fit within viewport
        const widthPerPanel = 100 / panelCount;
        
        console.log(`  Row ${row.id}: ${panelCount} panels, ${widthPerPanel}% each`);
        
        row.panels.forEach((panel, index) => {
          panelStore.updatePanel(panel.id, {
            widthPercent: widthPerPanel,
            orderInRow: index
          });
        });
      }
    });
  }
  
  // Handle panel resize
  function handlePanelResize(event: CustomEvent) {
    const { panelId, newWidth, newHeight, isLeftResize, moveTop, deltaY } = event.detail;
    const panel = $panels.find(p => p.id === panelId);
    if (!panel) return;

    // Update panel size
    const updates: Partial<Panel> = {};

    if (newWidth !== undefined) {
      const row = rows.find(r => r.panels.some(p => p.id === panelId));
      if (row) {
        // If this is the only panel in the row, allow free resizing up to 100%
        if (row.panels.length === 1) {
          // Allow single panels to resize freely between 10% and 100%
          updates.widthPercent = Math.max(10, Math.min(100, newWidth));
        } else {
          // For multiple panels, implement proper boundary dragging
          const panelIndex = row.panels.findIndex(p => p.id === panelId);

          if (!isLeftResize && panelIndex < row.panels.length - 1) {
            // Right resize - adjust this panel and the next panel
            const nextPanel = row.panels[panelIndex + 1];
            const currentWidth = panel.widthPercent || 25;
            const nextWidth = nextPanel.widthPercent || 25;
            const totalWidth = currentWidth + nextWidth;

            // Calculate new widths
            const newCurrentWidth = Math.max(10, Math.min(totalWidth - 10, newWidth));
            const newNextWidth = totalWidth - newCurrentWidth;

            updates.widthPercent = newCurrentWidth;

            // Update the next panel's width
            panelStore.updatePanel(nextPanel.id, { widthPercent: newNextWidth });
          } else if (isLeftResize && panelIndex > 0) {
            // Left resize - adjust this panel and the previous panel
            const prevPanel = row.panels[panelIndex - 1];
            const currentWidth = panel.widthPercent || 25;
            const prevWidth = prevPanel.widthPercent || 25;
            const totalWidth = currentWidth + prevWidth;

            // Calculate new widths
            const newCurrentWidth = Math.max(10, Math.min(totalWidth - 10, newWidth));
            const newPrevWidth = totalWidth - newCurrentWidth;

            updates.widthPercent = newCurrentWidth;

            // Update the previous panel's width
            panelStore.updatePanel(prevPanel.id, { widthPercent: newPrevWidth });
          } else {
            // Edge panels or single panel - just constrain the width
            const otherPanelsWidth = row.panels
              .filter(p => p.id !== panelId)
              .reduce((sum, p) => sum + (p.widthPercent || 0), 0);

            const maxAllowedWidth = 100 - otherPanelsWidth;
            const constrainedWidth = Math.min(newWidth, maxAllowedWidth);

            updates.widthPercent = constrainedWidth;
          }
        }
      } else {
        updates.widthPercent = newWidth;
      }
    }

    if (newHeight !== undefined) {
      updates.heightPixels = newHeight;

      // Update row height - IMPORTANT: We need to recreate the rows array to trigger Svelte reactivity
      const rowIndex = rows.findIndex(r => r.panels.some(p => p.id === panelId));
      if (rowIndex !== -1) {
        const row = rows[rowIndex];
        const oldHeight = row.height;
        let newRowHeight = row.height;

        if (moveTop) {
          // For top resize, maintain the bottom position
          newRowHeight = newHeight;
        } else {
          // For bottom resize, update to the new height
          newRowHeight = newHeight;
        }

        // Only update if height actually changed
        if (newRowHeight !== oldHeight) {
          console.log(`[RowLayout] Updating row ${row.id} height: ${oldHeight}px → ${newRowHeight}px`);

          // Update other panels in row to match height (but NOT the panel being resized)
          row.panels.forEach(p => {
            if (p.id !== panelId) {
              panelStore.updatePanel(p.id, { heightPixels: newRowHeight });
            }
          });

          // Recreate rows array to trigger Svelte reactivity
          rows = rows.map((r, idx) =>
            idx === rowIndex
              ? { ...r, height: newRowHeight }
              : r
          );
        }
      }
    }

    panelStore.updatePanel(panelId, updates);

    // Save layout changes to server to persist resize
    saveLayoutToServer();
  }
  
  // Handle panel close
  function handlePanelClose(event: CustomEvent) {
    const { panelId } = event.detail;
    panelStore.removePanel(panelId);
    recalculateRowWidths(true); // Force equal widths when closing a panel
    organizePanelsIntoRows();
    saveLayoutToServer();
  }

  // Handle edit custom panel
  function handleEditPanel(event: CustomEvent) {
    const { panelType } = event.detail;
    // Dispatch event to parent (MorphBoxLayout) to open edit modal
    window.dispatchEvent(new CustomEvent('edit-custom-panel', {
      detail: { panelType }
    }));
  }
  
  // Add new panel
  function handlePanelAction(event: CustomEvent) {
    const { action, panelType, panelData } = event.detail;
    
    switch (action) {
      case 'add':
        addNewPanel(panelType, panelData);
        break;
      case 'reset':
        resetLayout();
        break;
    }
  }
  
  // Add new panel to layout
  function addNewPanel(type: string, data?: any) {
    console.log('[RowLayout] Adding new panel:', { type, data });
    
    // Always create a new row at the bottom for new panels
    const newRowIndex = rows.length > 0 ? Math.max(...rows.map(r => parseInt(r.id.split('-')[1]))) + 1 : 0;
    
    // Get row height from settings
    const currentSettings = $settings;
    const rowHeight = currentSettings.panels?.rowHeight || 400;
    
    panelStore.addPanel(type, {
      ...data,
      rowIndex: newRowIndex,
      widthPercent: 100, // New panels take full width of new row
      heightPixels: rowHeight,
      orderInRow: 0
    });
    
    organizePanelsIntoRows();
    saveLayoutToServer();
    
    // Wait for DOM update then scroll to the new row
    setTimeout(() => {
      const newRow = document.querySelector(`#row-${newRowIndex}`);
      if (newRow && layoutContainer) {
        // Calculate the position to scroll to, accounting for any header height
        const rowTop = newRow.getBoundingClientRect().top;
        const containerTop = layoutContainer.getBoundingClientRect().top;
        const scrollTop = layoutContainer.scrollTop + (rowTop - containerTop);
        
        // Smooth scroll to the new row
        layoutContainer.scrollTo({
          top: scrollTop,
          behavior: 'smooth'
        });
      }
    }, 100);
  }
  
  // Load layout from server
  async function loadLayoutFromServer(): Promise<boolean> {
    try {
      const response = await fetch('/api/panels/layout');
      if (response.ok) {
        const layout = await response.json();
        if (layout && layout.panels && layout.panels.length > 0) {
          // Get current panels
          const currentPanels = $panels;
          
          // If we already have panels, update them instead of clearing
          if (currentPanels.length > 0) {
            console.log('📥 Updating existing layout from server');
            
            // Update existing panels to match server layout
            layout.panels.forEach((serverPanel: any) => {
              const existingPanel = currentPanels.find(p => p.type === serverPanel.type);
              if (existingPanel) {
                // Update existing panel properties without destroying it
                const { id, ...updateProps } = serverPanel;
                console.log('[loadLayoutFromServer] Updating existing panel:', existingPanel.id, 'with props:', updateProps);
                // Only update if properties actually changed
                const hasChanges = Object.keys(updateProps).some(key => 
                  JSON.stringify(existingPanel[key]) !== JSON.stringify(updateProps[key])
                );
                if (hasChanges) {
                  panelStore.updatePanel(existingPanel.id, updateProps);
                } else {
                  console.log('[loadLayoutFromServer] No changes for panel:', existingPanel.id);
                }
              } else {
                // Add new panel if it doesn't exist
                const { id, ...panelWithoutId } = serverPanel;
                panelStore.addPanel(serverPanel.type, panelWithoutId);
              }
            });
            
            // Remove panels that aren't in the server layout
            currentPanels.forEach(panel => {
              if (!layout.panels.find((p: any) => p.type === panel.type)) {
                panelStore.removePanel(panel.id);
              }
            });
          } else {
            // First time loading - create new panels
            panelStore.clear();
            layout.panels.forEach((panel: any) => {
              const { id, ...panelWithoutId } = panel;
              panelStore.addPanel(panel.type, panelWithoutId);
            });
          }
          
          organizePanelsIntoRows();
          // Don't recalculate widths on initial load - preserve saved widths
          console.log('📥 Loaded layout from server, preserving saved widths');
          return true;
        }
      }
    } catch (error) {
      console.error('Failed to load layout:', error);
    }
    return false;
  }
  
  // Save layout to server
  async function saveLayoutToServer() {
    try {
      await fetch('/api/panels/layout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          panels: $panels,
          rows: rows.map(r => ({ id: r.id, height: r.height }))
        })
      });
    } catch (error) {
      console.error('Failed to save layout:', error);
    }
  }
  
  // Reset layout
  async function resetLayout() {
    panelStore.clear();
    rows = [];
    
    await new Promise(resolve => setTimeout(resolve, 50));
    
    initializeLayout();
    
    try {
      await fetch('/api/panels/layout', { method: 'DELETE' });
    } catch (error) {
      console.error('Failed to clear server layout:', error);
    }
    
    saveLayoutToServer();
  }
  
  // Update rows when panels change
  $: if ($panels && browser) {
    try {
      console.log('🔄 Reactive: panels changed, organizing into rows');
      console.log('Panel count:', $panels.length);
      console.log('draggedPanelId:', draggedPanelId);
      organizePanelsIntoRows();
      // Log after reactive update
      setTimeout(() => {
        logRenderedDimensions();
      }, 0);
    } catch (error) {
      console.error('❌ Error organizing panels:', error);
      // Initialize with empty rows to prevent UI from being stuck
      rows = [];
    }
  }
  
  // Function to log actual rendered dimensions
  function logRenderedDimensions() {
    if (!browser || !layoutContainer) return;
    
    console.log('📐 Rendered Dimensions:');
    console.log('Layout container:', {
      width: layoutContainer.offsetWidth,
      clientWidth: layoutContainer.clientWidth,
      scrollWidth: layoutContainer.scrollWidth,
      computedStyle: {
        width: window.getComputedStyle(layoutContainer).width,
        maxWidth: window.getComputedStyle(layoutContainer).maxWidth,
        padding: window.getComputedStyle(layoutContainer).padding
      }
    });
    
    rows.forEach(row => {
      const rowElement = document.getElementById(row.id);
      if (rowElement) {
        console.log(`Row ${row.id}:`, {
          width: rowElement.offsetWidth,
          computedWidth: window.getComputedStyle(rowElement).width,
          computedFlex: window.getComputedStyle(rowElement).flex,
          computedDisplay: window.getComputedStyle(rowElement).display
        });
        
        row.panels.forEach(panel => {
          const panelContainer = rowElement.querySelector(`[data-panel-id="${panel.id}"]`);
          if (panelContainer) {
            const panelElement = panelContainer.querySelector('.row-panel');
            console.log(`  Panel ${panel.id} (${panel.type}):`, {
              widthPercent: panel.widthPercent,
              containerStyle: panelContainer.getAttribute('style'),
              containerWidth: panelContainer.offsetWidth,
              containerComputedStyle: {
                width: window.getComputedStyle(panelContainer).width,
                flex: window.getComputedStyle(panelContainer).flex,
                maxWidth: window.getComputedStyle(panelContainer).maxWidth
              },
              panelWidth: panelElement?.offsetWidth,
              panelComputedWidth: panelElement ? window.getComputedStyle(panelElement).width : 'N/A'
            });
          }
        });
      }
    });
  }
  
  // Load components for panels
  let panelComponentMap: Record<string, any> = {};
  
  // Use a more stable approach to prevent component remounting
  async function loadPanelComponents() {
    const newMap: Record<string, any> = {};
    
    for (const panel of $panels) {
      console.log('[RowLayout] Loading component for panel:', { id: panel.id, type: panel.type });
      
      // Reuse existing component if available
      if (panelComponentMap[panel.id]) {
        newMap[panel.id] = panelComponentMap[panel.id];
      } else {
        const component = await getComponentForPanel(panel.type);
        if (component) {
          newMap[panel.id] = component;
        }
      }
    }
    
    panelComponentMap = newMap;
  }
  
  // Only reload components when panels change
  $: if ($panels) {
    loadPanelComponents();
  }

  // Listen for panel reload events (from panel morphing)
  onMount(() => {
    const handleReloadPanel = (event: CustomEvent) => {
      const { panelId, timestamp } = event.detail;
      console.log('[RowLayout] Reload panel request:', { panelId, timestamp });

      // Find the panel type for this ID
      const panel = $panels.find(p => p.id === panelId || p.type === panelId);
      if (panel) {
        console.log('[RowLayout] Invalidating cached component for:', panel.type);

        // Remove from cache to force reload
        if (panelComponentMap[panel.id]) {
          delete panelComponentMap[panel.id];
        }

        // Also clear from loadedComponents cache
        if (loadedComponents[panel.type]) {
          delete loadedComponents[panel.type];
        }

        // Force component reload
        loadPanelComponents();

        // Add timestamp to force re-render by updating panel data
        panelStore.updatePanel(panel.id, {
          content: {
            ...panel.content,
            _reloadTimestamp: timestamp
          }
        });
      }
    };

    window.addEventListener('reload-panel', handleReloadPanel as EventListener);

    return () => {
      window.removeEventListener('reload-panel', handleReloadPanel as EventListener);
    };
  });
</script>

<div class="layout-container responsive-container" class:compact-mode={isCompactMode} class:stacked-layout={stackedLayout}>
  <!-- Section Tabs with Panel Manager -->
  <SectionTabs>
    <div slot="panel-manager">
      <PanelManager on:action={handlePanelAction} showReset={true} />
    </div>
  </SectionTabs>
  
  <!-- Row-based Layout -->
  <div 
    class="row-layout responsive-container" 
    bind:this={layoutContainer}
    data-viewport-width={viewportWidth}
    data-viewport-height={viewportHeight}
  >
    {#each rows as row (row.id)}
      <div
        id={row.id}
        class="row"
        style="height: {row.height}px; min-height: {row.height}px;"
      >
        {#if row.panels.length === 0}
          <div 
            class="empty-row"
            role="region"
            aria-label="Empty row drop zone"
            on:dragover={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; }}
            on:drop={(e) => {
              e.preventDefault();
              if (draggedPanelId) {
                movePanel(draggedPanelId, row.id);
                draggedPanelId = null;
                dropTargetInfo = null;
              }
            }}
          >
            <div class="drop-hint">Drop panel here</div>
          </div>
        {:else}
          {@const panelIds = row.panels.map(p => p.id)}
          {@const hasDuplicates = panelIds.length !== new Set(panelIds).size}
          {@debug panelIds, hasDuplicates}
          {#each row.panels as panel (panel.id)}
            {#if panelComponentMap[panel.id]}
              <div
                class="panel-container"
                style="{row.panels.length === 1 ? `width: ${panel.widthPercent || 100}%; flex: none;` : `flex: 1 1 ${panel.widthPercent || 25}%;`}"
                data-panel-id={panel.id}
              >
                <RowPanel
                  {panel}
                  component={panelComponentMap[panel.id]}
                  {websocketUrl}
                  isDragging={draggedPanelId === panel.id}
                  isActive={$activePanel?.id === panel.id}
                  isFirstInRow={panel.orderInRow === 0}
                  on:dragstart={handleDragStart}
                  on:click={() => panelStore.setActivePanel(panel.id)}
                  on:dragend={handleDragEnd}
                  on:drop={handlePanelDrop}
                  on:resize={handlePanelResize}
                  on:open={handleFileOpen}
                  on:close={handlePanelClose}
                  on:edit-panel={handleEditPanel}
                />
              </div>
            {/if}
          {/each}
        {/if}
      </div>
    {/each}
    
    <!-- Add new row drop zone -->
    {#if draggedPanelId}
      <div 
        class="new-row-drop-zone"
        role="region"
        aria-label="New row drop zone"
        on:dragover={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; }}
        on:drop={(e) => {
          e.preventDefault();
          if (draggedPanelId) {
            const newRowIndex = rows.length;
            movePanel(draggedPanelId, `row-${newRowIndex}`);
            draggedPanelId = null;
            dropTargetInfo = null;
          }
        }}
      >
        <div class="drop-hint">Drop here to create new row</div>
      </div>
    {/if}
  </div>
</div>

<!-- Loading overlay -->
{#if showLoadingOverlay}
  <div class="global-loading-overlay" transition:fade={{ duration: 400 }}>
    <img src="/splashlogo.png" alt="MorphBox" class="loading-logo" />
  </div>
{/if}

<style>
  .layout-container {
    display: flex;
    flex-direction: column;
    height: 100vh;
    height: 100dvh;
    width: 100vw;
    background-color: var(--bg-primary, #1e1e1e);
    color: var(--text-primary, #d4d4d4);
    overflow: hidden;
    container-type: inline-size;
    position: relative; /* Ensure proper positioning context */
  }
  
  .row-layout {
    flex: 1;
    width: 100%;
    max-width: 100%;
    overflow-x: hidden; /* No horizontal scroll needed */
    overflow-y: auto;
    scroll-behavior: smooth;
    background-color: var(--bg-secondary, #252526);
    /* Reduce padding to maximize space for panels */
    padding: 0;
    box-sizing: border-box;
    container-type: inline-size;
    /* Add padding at bottom to ensure last panel's resize handle is accessible */
    padding-bottom: 30px;
  }
  
  /* Custom scrollbar styling for vertical scrolling only */
  .row-layout::-webkit-scrollbar {
    width: 8px;
  }
  
  .row-layout::-webkit-scrollbar-track {
    background: var(--scrollbar-track, #2a2a2a);
    border-radius: 4px;
  }
  
  .row-layout::-webkit-scrollbar-thumb {
    background: var(--scrollbar-thumb, #555);
    border-radius: 4px;
  }
  
  .row-layout::-webkit-scrollbar-thumb:hover {
    background: var(--scrollbar-thumb-hover, #777);
  }
  
  .row {
    display: flex;
    width: 100%;
    max-width: 100%; /* Use container width */
    margin-bottom: var(--spacing-sm);
    position: relative;
    box-sizing: border-box;
    overflow: visible; /* Changed to visible to allow resize handles to extend beyond */
    flex-wrap: nowrap;
    transition: margin 0.3s ease;
    background-color: var(--bg-primary, #1e1e1e); /* Add background to show empty space */
    /* Remove padding to maximize panel width */
    padding: 0 4px; /* Small padding for edge visibility */
  }
  
  .panel-container {
    /* Remove horizontal padding to maximize panel width */
    box-sizing: border-box;
    height: 100%;
    display: flex;
    min-width: 0; /* Allow panels to shrink as needed */
    overflow: hidden;
    transition: width 0.3s ease, flex 0.3s ease;
    /* Use flex properties from inline style */
    padding: 0 2px; /* Small padding to prevent panels from touching */
  }
  
  .empty-row {
    width: 100%;
    height: 100%;
    border: 2px dashed var(--panel-border, #3e3e42);
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: var(--bg-tertiary, #2d2d30);
    border-radius: 4px;
  }
  
  .new-row-drop-zone {
    height: 100px;
    margin: 8px 0;
    border: 2px dashed var(--accent-color, #0e639c);
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(14, 99, 156, 0.1);
    border-radius: 4px;
  }
  
  .drop-hint {
    color: var(--text-secondary, #858585);
    font-size: 14px;
    pointer-events: none;
  }
  
  /* Loading overlay */
  .global-loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background-color: #1e1e1e;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2147483647;
  }
  
  .loading-logo {
    width: 100vw;
    height: 100vh;
    object-fit: contain;
    object-position: center;
  }
  
  /* Container queries for panel-aware responsiveness */
  @container (max-width: 600px) {
    .row {
      flex-direction: column;
      margin-bottom: var(--spacing-xs);
    }
    
    .panel-container {
      width: 100% !important;
      max-width: 100% !important;
      flex: 1 1 100% !important;
      margin-bottom: var(--spacing-xs);
    }
    
    .panel-container:last-child {
      margin-bottom: 0;
    }
    
    .new-row-drop-zone {
      height: 60px;
      font-size: var(--font-size-sm);
    }
  }
  
  @container (min-width: 600px) and (max-width: 900px) {
    /* 2-column max layout for medium containers */
    .row:has(.panel-container:nth-child(3)) {
      flex-wrap: wrap;
    }
    
    .row:has(.panel-container:nth-child(3)) .panel-container {
      width: 50% !important;
      max-width: 50% !important;
      flex: 1 1 50% !important;
    }
  }
  
  /* Viewport-based responsive styles */
  @media (max-width: 768px) {
    .row-layout {
      /* Remove padding on mobile to maximize space */
      padding: 0;
    }
    
    .row {
      flex-direction: column;
      margin-bottom: var(--spacing-xs);
      min-height: auto;
      /* Add extra padding at bottom for resize handles */
      padding-bottom: 20px;
      min-width: unset; /* Allow mobile rows to fit viewport */
    }
    
    .panel-container {
      width: 100% !important;
      max-width: 100% !important;
      flex: 1 1 100% !important;
      min-width: unset !important; /* Override min-width on mobile */
      /* padding: 0; Keep this to ensure no padding on mobile */
      padding: 0;
      margin-bottom: var(--spacing-xs);
    }
    
    .panel-container:last-child {
      margin-bottom: 0;
    }
    
    .empty-row,
    .new-row-drop-zone {
      height: 80px;
      font-size: var(--font-size-sm);
    }
    
    .drop-hint {
      font-size: var(--font-size-xs);
    }
  }
  
  @media (min-width: 768px) and (max-width: 1024px) {
    /* Tablet: limit to 2 panels per row */
    .row:has(.panel-container:nth-child(3)) {
      flex-wrap: wrap;
    }
    
    .row:has(.panel-container:nth-child(3)) .panel-container {
      width: 50% !important;
      max-width: 50% !important;
      flex: 1 1 calc(50% - var(--spacing-xs)) !important;
    }
  }
  
  /* Touch-friendly adjustments */
  @media (pointer: coarse) {
    .drop-hint {
      font-size: var(--font-size-base);
      padding: var(--spacing-md);
    }
    
    .new-row-drop-zone,
    .empty-row {
      min-height: var(--touch-target-min);
    }
  }
  
  /* High DPI screens */
  @media (min-resolution: 2dppx) {
    .panel-container {
      border-radius: 2px;
    }
  }
  
  /* Performance optimizations for animations */
  @media (prefers-reduced-motion: reduce) {
    .row,
    .panel-container {
      transition: none;
    }
  }
</style>